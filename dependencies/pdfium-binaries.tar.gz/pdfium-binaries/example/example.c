#include <fpdfview.h>

int main()
{
	FPDF_InitLibrary();

	FPDF_DestroyLibrary();
	return 0;
}